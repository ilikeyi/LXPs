﻿ConvertFrom-StringData -StringData @'
	# ru-RU
	# Russian (Russia)

	UpdateCreate              = Создать пакет обновления
	UpdateLow                 = Минимальные требования: \
	UpCreateRear              = Что делать после создания
	UpCreateASC               = Добавьте подпись PGP в пакет обновления
	NoPGPKey                  = В PGP отсутствует пригодный для использования закрытый ключ.
	CreateASCPwd              = Пароль сертификата
	CreateASCAuthor           = Подписавший
	CreateASCAuthorTips       = Подписывающие стороны не выбраны.
	UpCreateSHA256            = Создайте .SHA-256 для пакета обновления.
	SelectFromError           = Ошибка
	Uping                     = Создание
	SkipCreate                = Пропустить генерацию, не найдено
	SoftIsInstl                 = {0} не установлен.
	ShowPassword              = Показать пароль
'@