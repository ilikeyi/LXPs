﻿ConvertFrom-StringData -StringData @'
	# he-IL
	# Hebrew (Israel)

	FontsUI                   = Segoe UI
	LXPs                      = חבילות חוויית שפה מקומית (LXPs)
	Menu                      = תַפרִיט
	Learn                     = לִלמוֹד
	AddTo                     = הוסף ל
	Del                       = לִמְחוֹק
	Done                      = סִיוּם
	Failed                    = לְהִכָּשֵׁל
	OK                        = בַּטוּחַ
	Cancel                    = לְבַטֵל
	AllSel                    = בחר הכל
	AllClear                  = לנקות הכל
	Operable                  = נָתִיחַ
	Inoperable                = בלתי ניתן להפעלה
	SwitchLanguage            = להחליף שפה
	LanguageReset             = אפס את הגדרות השפה
	LanguageCode              = סימן אזור
	RefreshModules            = רענון חם של כל המודולים
	PleaseChoose              = נא לבחור
	PleaseChooseMain          = קיצור או בחירה
	FailedCreateFolder        = יצירת הספרייה נכשלה
	ToMsg                     = \n   {0} חזור אוטומטית לתפריט הראשי לאחר שניות.
	ToQuit                    = \n   {0} צא מהתפריט הראשי לאחר שניות.
	UserCancel                = המשתמש ביטל את הפעולה.
	Detailed                  = מְפוֹרָט
	FileName                  = שם הקובץ
	Help                      = עֶזרָה
	WorkDone                  = הושלם, הקש על מקש כלשהו כדי לחזור לממשק הראשי...
	Short_Cmd                 = קיצורי דרך
'@