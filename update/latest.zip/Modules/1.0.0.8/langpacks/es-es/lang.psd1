﻿ConvertFrom-StringData -StringData @'
	# es-ES
	# Spanish (Spain)

	FontsUI                   = Segoe UI
	LXPs                      = Paquetes de experiencia en idiomas locales (LXPs)
	Menu                      = Menú
	Learn                     = Estudiar
	AddTo                     = Añadir
	Done                      = Finalizar
	Failed                    = Fallar
	OK                        = Seguro
	Cancel                    = Cancelar
	AllSel                    = Seleccionar todo
	AllClear                  = Borrar todo
	Operable                  = Operable
	Inoperable                = Inoperable
	SwitchLanguage            = Cambiar de idioma
	LanguageReset             = Restablecer la configuración de idioma
	LanguageCode              = Marca de zona
	RefreshModules            = Actualización en caliente de todos los módulos
	PleaseChoose              = Por favor seleccione
	PleaseChooseMain          = Acceso directo o selección
	FailedCreateFolder        = No se pudo crear el directorio:
	ToMsg                     = \n   {0} Regresa automáticamente al menú principal después de unos segundos.
	ToQuit                    = \n   {0} Salga del menú principal después de unos segundos.
	UserCancel                = El usuario ha cancelado la operación.
	Detailed                  = Detallado
	FileName                  = Nombre del archivo
	Help                      = Ayuda
	WorkDone                  = Completado, presione cualquier tecla para regresar a la interfaz principal...
	Short_Cmd                 = Atajos
'@