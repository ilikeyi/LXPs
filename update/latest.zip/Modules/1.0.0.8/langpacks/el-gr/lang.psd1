﻿ConvertFrom-StringData -StringData @'
	# el-GR
	# Greek (Greece)

	FontsUI                   = Segoe UI
	LXPs                      = Πακέτα εμπειρίας τοπικής γλώσσας (LXPs)
	Menu                      = Μενού
	Learn                     = Μελέτη
	AddTo                     = Προσθήκη σε
	Del                       = Διαγράφω
	Done                      = Φινίρισμα
	Failed                    = Αποτυγχάνω
	OK                        = Σίγουρος
	Cancel                    = Ματαίωση
	AllSel                    = Επιλέξτε όλα
	AllClear                  = Καθαρίστε όλα
	Operable                  = Εγχειρήσιμος
	Inoperable                = Μη χειρουργήσιμος
	SwitchLanguage            = Αλλαγή γλώσσας
	LanguageReset             = Επαναφορά ρυθμίσεων γλώσσας
	LanguageCode              = Σήμα ζώνης
	RefreshModules            = Ζεστή ανανέωση όλων των μονάδων
	PleaseChoose              = Επιλέξτε
	PleaseChooseMain          = Συντόμευση ή επιλογή
	FailedCreateFolder        = Αποτυχία δημιουργίας καταλόγου
	ToMsg                     = \n   {0} Αυτόματη επιστροφή στο κύριο μενού μετά από δευτερόλεπτα.
	UserCancel                = Ο χρήστης ακύρωσε τη λειτουργία.
	Detailed                  = Λεπτομερής
	FileName                  = Όνομα αρχείου
	Help                      = Βοήθεια
	WorkDone                  = Ολοκληρώθηκε, πατήστε οποιοδήποτε πλήκτρο για να επιστρέψετε στην κύρια διεπαφή...
	Short_Cmd                 = Συντομεύσεις
	Enable                    = Καθιστώ ικανό
	Disable                   = Καθιστώ ανίκανο
	Setting                   = Στήνω
'@