﻿ConvertFrom-StringData -StringData @'
	# ro-RO
	# Romanian (Romania)

	FontsUI                   = Segoe UI
	LXPs                      = Pachete de experiență în limba locală (LXPs)
	Menu                      = Meniu
	Learn                     = Studiu
	AddTo                     = Adaugă la
	Done                      = Termina
	Failed                    = Eșuează
	OK                        = Sigur
	Cancel                    = Anula
	AllSel                    = Selectați toate
	AllClear                  = Șterge totul
	Operable                  = Operabil
	Inoperable                = Inoperabil
	SwitchLanguage            = Schimba limba
	LanguageReset             = Resetați setările de limbă
	LanguageCode              = Marcajul zonei
	RefreshModules            = Actualizează la cald toate modulele
	PleaseChoose              = Vă rugăm să selectați
	PleaseChooseMain          = Comandă rapidă sau selecție
	FailedCreateFolder        = Nu s-a putut crea directorul:
	ToMsg                     = \n   {0} Reveniți automat la meniul principal după câteva secunde.
	ToQuit                    = \n   {0} Ieșiți din meniul principal după câteva secunde.
	UserCancel                = Utilizatorul a anulat operația.
	Detailed                  = Detaliat
	FileName                  = Nume de fișier
	Help                      = Ajutor
	WorkDone                  = Finalizat, apăsați orice tastă pentru a reveni la interfața principală...
	Short_Cmd                 = Comenzi rapide
'@